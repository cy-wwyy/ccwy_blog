module.exports=[5307,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_albums_page_actions_199xoae.js.map