module.exports=[83397,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_albums_%5Bslug%5D_page_actions_1gt4wj-.js.map