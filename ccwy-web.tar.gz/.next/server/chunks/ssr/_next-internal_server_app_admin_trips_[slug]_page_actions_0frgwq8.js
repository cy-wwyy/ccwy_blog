module.exports=[41004,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_trips_%5Bslug%5D_page_actions_0frgwq8.js.map