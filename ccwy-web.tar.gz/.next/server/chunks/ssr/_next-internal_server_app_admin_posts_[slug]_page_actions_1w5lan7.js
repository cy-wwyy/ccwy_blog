module.exports=[47575,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_posts_%5Bslug%5D_page_actions_1w5lan7.js.map