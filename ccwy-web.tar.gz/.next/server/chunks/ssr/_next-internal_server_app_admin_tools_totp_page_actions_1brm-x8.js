module.exports=[15447,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_tools_totp_page_actions_1brm-x8.js.map