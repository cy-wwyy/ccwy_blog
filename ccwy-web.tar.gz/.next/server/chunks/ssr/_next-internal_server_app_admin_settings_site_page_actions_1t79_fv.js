module.exports=[97879,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_settings_site_page_actions_1t79_fv.js.map