module.exports=[28105,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_projects_page_actions_0z56azi.js.map