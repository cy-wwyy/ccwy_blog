module.exports=[93086,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_albums_%5Bslug%5D_page_actions_1uilsae.js.map