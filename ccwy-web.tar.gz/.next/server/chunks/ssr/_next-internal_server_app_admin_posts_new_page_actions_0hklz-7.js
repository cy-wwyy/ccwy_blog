module.exports=[3976,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_posts_new_page_actions_0hklz-7.js.map