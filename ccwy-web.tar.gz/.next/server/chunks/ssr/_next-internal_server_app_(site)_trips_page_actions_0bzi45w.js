module.exports=[758,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_trips_page_actions_0bzi45w.js.map