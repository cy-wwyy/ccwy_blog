module.exports=[47210,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_settings_profile_page_actions_0m9i-od.js.map