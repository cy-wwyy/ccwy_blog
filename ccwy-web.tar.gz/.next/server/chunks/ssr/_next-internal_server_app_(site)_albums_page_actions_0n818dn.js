module.exports=[46575,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28site%29_albums_page_actions_0n818dn.js.map