globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/wvRebhOBgnpPhyILsyavr/_buildManifest.js",
    "static/wvRebhOBgnpPhyILsyavr/_ssgManifest.js",
    "static/wvRebhOBgnpPhyILsyavr/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/2iho8jepmwwua.js",
    "static/chunks/0p5zcrse83l6u.js",
    "static/chunks/0a5djlgv2umm2.js",
    "static/chunks/1zvw1vw5-qhe9.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/turbopack-2ft9gighelos7.js"
  ]
};
