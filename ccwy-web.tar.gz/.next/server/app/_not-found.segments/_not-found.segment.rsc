1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0dwysghmabddm.js","/_next/static/chunks/1j7ewxulspe91.js","/_next/static/chunks/33lwv-iavfj1-.js","/_next/static/chunks/2pun46soklm-s.js","/_next/static/chunks/11tc9ceq7j--k.js","/_next/static/chunks/1c5k5atosts74.js","/_next/static/chunks/3rr22k1malkh0.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
3:I[37457,["/_next/static/chunks/0dwysghmabddm.js","/_next/static/chunks/1j7ewxulspe91.js","/_next/static/chunks/33lwv-iavfj1-.js","/_next/static/chunks/2pun46soklm-s.js","/_next/static/chunks/11tc9ceq7j--k.js","/_next/static/chunks/1c5k5atosts74.js","/_next/static/chunks/3rr22k1malkh0.js","/_next/static/chunks/14mrh2-p_w84d.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"wvRebhOBgnpPhyILsyavr"}
